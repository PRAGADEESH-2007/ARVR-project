/* ==========================================================================
   AR HISTORICAL MUSEUM - JAVASCRIPT ENGINE
   Pure Vanilla JS Implementation (Zero Dependencies)
   ========================================================================== */

// --------------------------------------------------------------------------
// 1. Initial Sample Artifacts Dataset
// --------------------------------------------------------------------------
const initialArtifacts = [
    {
        id: 1,
        name: "Ancient Chola Bronze Statue",
        category: "Sculpture",
        period: "Chola Dynasty",
        origin: "Tamil Nadu, India",
        year: "1100 CE",
        color: "#f59e0b",
        visualType: "statue",
        description: "A breathtaking lost-wax cast bronze masterpiece representing traditional South Indian sacred icon sculpture. Renowned for its exquisite anatomical balance and fluidity.",
        significance: "Demonstrates the pinnacle of medieval metallurgy and lost-wax casting technique (Cire Perdue) during the golden era of Emperor Rajaraja Chola I.",
        facts: [
            "Cast using a seamless single-piece bronze technique.",
            "Features distinct flame-crowned hair (Jatamukuta).",
            "Maintained intact in temple sanctums for over 900 years."
        ]
    },
    {
        id: 2,
        name: "Gupta Period Gold Dinar Coin",
        category: "Coins",
        period: "Gupta Empire",
        origin: "Pataliputra, Ancient India",
        year: "380 CE",
        color: "#fbbf24",
        visualType: "coin",
        description: "A rare solid gold coin issued under Emperor Chandragupta II, featuring imperial lion-slayer motifs and Brahmi script inscriptions.",
        significance: "Reflects the economic prosperity, gold currency standards, and artistic elegance of India's Golden Age of classical literature and science.",
        facts: [
            "Minted with over 90% pure high-purity gold.",
            "Bears legendary Brahmi legend praising royal valor.",
            "Used in maritime trade across the ancient Silk Road."
        ]
    },
    {
        id: 3,
        name: "Sacred Temple Brass Lamp",
        category: "Sculpture",
        period: "Vijayanagara Period",
        origin: "Hampi, Karnataka",
        year: "1520 CE",
        color: "#d97706",
        visualType: "lamp",
        description: "An ornate multi-tiered ceremonial oil lamp (Deepastambha) topped with a majestic sacred swan (Hamsa) symbol of purity.",
        significance: "Illuminated ritual halls in royal temples of Hampi, exemplifying Vijayanagara architectural brass metalwork.",
        facts: [
            "Hand-carved with 108 oil wick reservoirs.",
            "Engineered with balanced counterweight base physics.",
            "Preserved with original antique patina finish."
        ]
    },
    {
        id: 4,
        name: "Indus Valley Terracotta Jar",
        category: "Pottery",
        period: "Harappan Civilization",
        origin: "Mohenjo-daro",
        year: "2500 BCE",
        color: "#b45309",
        visualType: "pottery",
        description: "A wheel-thrown terracotta storage vessel painted with black geometric motifs and naturalistic pipal leaf patterns.",
        significance: "Proves advanced urban ceramic technology, wheel-spinning skills, and slip painting methods of proto-historic South Asia.",
        facts: [
            "Over 4,500 years old from the Bronze Age.",
            "Waterproofed using natural tree resin slips.",
            "Discovered intact during 20th-century excavations."
        ]
    },
    {
        id: 5,
        name: "Imperial Palm-Leaf Manuscript",
        category: "Manuscripts",
        period: "Pala Empire",
        origin: "Nalanda, Bihar",
        year: "1050 CE",
        color: "#854d0e",
        visualType: "manuscript",
        description: "A sacred Sanskrit manuscript etched onto dried Palmyra palm leaves, bound with silk cords and wooden protective covers.",
        significance: "Contains rare astronomical treatises and philosophical commentaries written by Buddhist scholars at Nalanda University.",
        facts: [
            "Etched with iron styluses and treated with lampblack ink.",
            "Survived centuries due to natural neem leaf preservation.",
            "Features miniature gouache pigment illustrations."
        ]
    },
    {
        id: 6,
        name: "Hampi Carved Granite Pillar",
        category: "Architecture",
        period: "Vijayanagara Period",
        origin: "Karnataka, India",
        year: "1450 CE",
        color: "#64748b",
        visualType: "sculpture",
        description: "A miniature monolith carved from solid pink granite, depicting mythical Yali creatures and musical pillar fluting.",
        significance: "Represents the monolithic architectural grandeur of the UNESCO World Heritage stone temples of Hampi.",
        facts: [
            "Carved from a single solid granite block.",
            "Produces distinct musical tones when tapped.",
            "Synthesizes Dravidian and Deccan stone craft styles."
        ]
    },
    {
        id: 7,
        name: "Royal Rajput Damascened Sword",
        category: "Weapons",
        period: "Mughal-Rajput Era",
        origin: "Rajasthan, India",
        year: "1680 CE",
        color: "#475569",
        visualType: "weapon",
        description: "A ceremonial Khanda broadsword featuring Wootz crucible steel with gold Koftgari damascening on the hilt.",
        significance: "Highlights legendary Indian crucible Wootz steelmaking, famed globally for razor sharpness and watered silk blade patterns.",
        facts: [
            "Forged using high-carbon Wootz crucible steel.",
            "Hilt inlaid with 24-karat gold wire work.",
            "Worn by royal commanders during ceremonial durbars."
        ]
    },
    {
        id: 8,
        name: "Greco-Buddhist Relief Panel",
        category: "Sculpture",
        period: "Gandhara Kingdom",
        origin: "Taxila, Ancient Gandhara",
        year: "150 CE",
        color: "#94a3b8",
        visualType: "sculpture",
        description: "A gray schist stone carving depicting Hellenistic drapery folds blended with traditional Indian spiritual icons.",
        significance: "Demonstrates historic cultural synthesis along ancient Silk Road trade routes linking Greco-Roman and Asian traditions.",
        facts: [
            "Carved from blue-gray Gandharan schist stone.",
            "Combines Roman toga drapery with Eastern motifs.",
            "Unearthed near Taxila monastic archaeological sites."
        ]
    },
    {
        id: 9,
        name: "Tutankhamun's Golden Burial Mask",
        category: "Sculpture",
        period: "New Kingdom Egypt",
        origin: "Valley of the Kings, Luxor, Egypt",
        year: "1323 BCE",
        color: "#eab308",
        visualType: "tut_mask",
        description: "The iconic solid gold death mask of 18th Dynasty Pharaoh Tutankhamun, inlaid with lapis lazuli, turquoise, carnelian, and colored glass.",
        significance: "Universally recognized symbol of Ancient Egypt and one of the finest metallurgical achievements in human history.",
        facts: [
            "Crafted from two joined sheets of heavy hammered gold weighing 10.23 kg.",
            "Inscribed on the back with protective spells from the Book of the Dead.",
            "Discovered by Howard Carter in 1922 inside tomb KV62."
        ]
    },
    {
        id: 10,
        name: "The Rosetta Stone Stele",
        category: "Manuscripts",
        period: "Ptolemaic Dynasty",
        origin: "Rashid (Rosetta), Egypt",
        year: "196 BCE",
        color: "#475569",
        visualType: "rosetta",
        description: "A granodiorite stele inscribed with a decree issued at Memphis in three scripts: Ancient Egyptian hieroglyphs, Demotic script, and Ancient Greek.",
        significance: "Provided the vital key to deciphering ancient Egyptian hieroglyphic writing, unlocking thousands of years of recorded Egyptian history.",
        facts: [
            "Contains the exact same royal decree written in three distinct writing scripts.",
            "Deciphered by Jean-François Champollion in 1822.",
            "Housed in the British Museum since 1802."
        ]
    },
    {
        id: 11,
        name: "Dancing Girl of Mohenjo-Daro",
        category: "Sculpture",
        period: "Harappan Civilization",
        origin: "Mohenjo-daro, Sindh",
        year: "2500 BCE",
        color: "#b45309",
        visualType: "dancing_girl",
        description: "A rare prehistoric bronze statuette of a young woman standing in a naturalistic poise with her left hand covered in bangles resting on her thigh.",
        significance: "Reveals high sophistication in lost-wax metal casting (Cire Perdue) and realistic human depiction in proto-historic South Asia.",
        facts: [
            "Over 4,500 years old, measuring 10.5 cm in height.",
            "Features 25 bangles on her left arm and 4 on her right arm.",
            "Excavated by Ernest Mackay in 1926 at Mohenjo-daro."
        ]
    },
    {
        id: 12,
        name: "Aztec Sun Stone Calendar",
        category: "Architecture",
        period: "Aztec Empire",
        origin: "Tenochtitlan, Mexico City",
        year: "1479 CE",
        color: "#d97706",
        visualType: "aztec_sun",
        description: "A colossal 24-ton carved basalt monolith representing the Aztec creation cosmology, solar cycles, and sacred ritual calendar.",
        significance: "Highlights advanced Mesoamerican astronomy, mathematical calendar systems, and intricate stone carving artistry.",
        facts: [
            "Measures 3.58 meters in diameter and weighs 24 metric tons.",
            "Carved during the reign of Aztec Emperor Axayacatl.",
            "Features the face of solar deity Tonatiuh at its center."
        ]
    },
    {
        id: 13,
        name: "Imperial Qin Terracotta Warrior",
        category: "Sculpture",
        period: "Qin Dynasty",
        origin: "Xi'an, Shaanxi, China",
        year: "210 BCE",
        color: "#9a3412",
        visualType: "terracotta",
        description: "A life-sized terracotta sculpture of an imperial infantry soldier, part of the necropolis army guarding Emperor Qin Shi Huang in the afterlife.",
        significance: "Demonstrates unprecedented mass ceramic sculpting, military organization, and imperial scale in ancient China.",
        facts: [
            "Every single warrior figure possesses unique facial features and expressions.",
            "Part of an underground army of over 8,000 soldiers and horses.",
            "Discovered by local farmers digging a water well in 1974."
        ]
    },
    {
        id: 14,
        name: "Cyrus Cylinder of Universal Rights",
        category: "Manuscripts",
        period: "Achaemenid Empire",
        origin: "Babylon, Ancient Mesopotamia",
        year: "539 BCE",
        color: "#d97706",
        visualType: "cyrus_cylinder",
        description: "A barrel-shaped clay cylinder inscribed in Akkadian cuneiform by Cyrus the Great of Persia after conquering Babylon.",
        significance: "Widely regarded as the world's first charter of human rights and religious freedom for conquered populations.",
        facts: [
            "Inscribed in Babylonian cuneiform script on baked clay.",
            "Promoted freedom of worship and allowed exiled captives to return home.",
            "Discovered at the site of Babylon in 1879."
        ]
    }
];

// --------------------------------------------------------------------------
// 2. State & Storage Engine
// --------------------------------------------------------------------------
let artifactsState = [];
let favoritesState = [];
let recentState = [];
let arScanCount = 24;
let activeSection = 'home';
let currentCategory = 'All';
let searchQuery = '';
let currentSort = 'newest';
let selectedARArtifactId = 1;

// AR Studio Physics State
let arTransform = {
    posX: 0,
    posY: 0,
    rotX: 0,
    rotY: 0,
    rotZ: 0,
    scale: 1.0
};
let isDragging = false;
let dragStartPos = { x: 0, y: 0 };
let isAutoSpinning = false;
let autoSpinAnimationFrame = null;

// --------------------------------------------------------------------------
// 3. Initialization & LocalStorage Sync
// --------------------------------------------------------------------------
document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    loadStateFromStorage();
    renderHeroPreview();
    updateDashboardStats();
    renderExploreGrid();
    populateARArtifactSelect();
    renderAdminTable();
    setupEventListeners();
    setupARInteractions();
});

function loadStateFromStorage() {
    // Custom added/edited artifacts
    const storedCustom = localStorage.getItem('ar_museum_custom');
    if (storedCustom) {
        try {
            const customItems = JSON.parse(storedCustom);
            artifactsState = [...initialArtifacts, ...customItems];
        } catch (e) {
            artifactsState = [...initialArtifacts];
        }
    } else {
        artifactsState = [...initialArtifacts];
    }

    // Favorites
    const storedFavs = localStorage.getItem('ar_museum_favorites');
    if (storedFavs) {
        try { favoritesState = JSON.parse(storedFavs); } catch (e) { favoritesState = []; }
    }

    // Recently Viewed
    const storedRecent = localStorage.getItem('ar_museum_recent');
    if (storedRecent) {
        try { recentState = JSON.parse(storedRecent); } catch (e) { recentState = []; }
    }

    // AR Scans Count
    const storedScans = localStorage.getItem('ar_museum_scans');
    if (storedScans) {
        arScanCount = parseInt(storedScans, 10) || 24;
    }

    updateFavBadge();
}

function saveCustomArtifactsToStorage(customArray) {
    localStorage.setItem('ar_museum_custom', JSON.stringify(customArray));
}

function saveFavoritesToStorage() {
    localStorage.setItem('ar_museum_favorites', JSON.stringify(favoritesState));
    updateFavBadge();
    updateDashboardStats();
}

function saveRecentToStorage() {
    localStorage.setItem('ar_museum_recent', JSON.stringify(recentState));
    updateDashboardStats();
}

function incrementARScanCount() {
    arScanCount++;
    localStorage.setItem('ar_museum_scans', arScanCount.toString());
    updateDashboardStats();
}

function updateFavBadge() {
    const badge = document.getElementById('fav-count-badge');
    if (badge) badge.textContent = favoritesState.length.toString();
}

// --------------------------------------------------------------------------
// 4. SVG Vector Art Generator (No External Image Dependency)
// --------------------------------------------------------------------------
function renderArtifactSVG(artifact, size = 200) {
    const color = artifact.color || '#f59e0b';
    const type = artifact.visualType || 'statue';

    switch (type) {
        case 'coin':
            return `
                <svg width="${size}" height="${size}" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                    <defs>
                        <radialGradient id="coinGrad_${artifact.id}" cx="35%" cy="35%" r="65%">
                            <stop offset="0%" stop-color="#fde047" />
                            <stop offset="50%" stop-color="${color}" />
                            <stop offset="100%" stop-color="#854d0e" />
                        </radialGradient>
                    </defs>
                    <circle cx="100" cy="100" r="85" fill="url(#coinGrad_${artifact.id})" stroke="#fbbf24" stroke-width="4" />
                    <circle cx="100" cy="100" r="75" fill="none" stroke="#78350f" stroke-width="2" stroke-dasharray="6,4" />
                    <path d="M100 45 L115 80 L150 85 L125 110 L130 145 L100 130 L70 145 L75 110 L50 85 L85 80 Z" fill="#78350f" opacity="0.35" />
                    <circle cx="100" cy="100" r="35" fill="none" stroke="#fde047" stroke-width="3" />
                    <text x="100" y="108" font-family="Cinzel, serif" font-size="24" font-weight="bold" fill="#451a03" text-anchor="middle">👑</text>
                </svg>`;
        case 'lamp':
            return `
                <svg width="${size}" height="${size}" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                    <defs>
                        <linearGradient id="lampGrad_${artifact.id}" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="#fbbf24" />
                            <stop offset="100%" stop-color="#b45309" />
                        </linearGradient>
                    </defs>
                    <!-- Flame -->
                    <path d="M100 15 Q115 40 100 60 Q85 40 100 15 Z" fill="#ef4444" />
                    <path d="M100 25 Q108 40 100 55 Q92 40 100 25 Z" fill="#fde047" />
                    <!-- Body -->
                    <path d="M70 170 L130 170 L120 140 L80 140 Z" fill="url(#lampGrad_${artifact.id})" />
                    <rect x="92" y="90" width="16" height="50" fill="url(#lampGrad_${artifact.id})" />
                    <path d="M40 90 C40 60 160 60 160 90 C150 115 50 115 40 90 Z" fill="url(#lampGrad_${artifact.id})" stroke="#78350f" stroke-width="2" />
                    <ellipse cx="100" cy="170" rx="45" ry="12" fill="#78350f" />
                </svg>`;
        case 'pottery':
            return `
                <svg width="${size}" height="${size}" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                    <defs>
                        <linearGradient id="potGrad_${artifact.id}" x1="0%" y1="0%" x2="100%" y2="0%">
                            <stop offset="0%" stop-color="#9a3412" />
                            <stop offset="40%" stop-color="#ea580c" />
                            <stop offset="100%" stop-color="#7c2d12" />
                        </linearGradient>
                    </defs>
                    <ellipse cx="100" cy="40" rx="35" ry="10" fill="#7c2d12" stroke="#ea580c" stroke-width="2" />
                    <path d="M65 40 C40 80 30 130 65 170 C80 185 120 185 135 170 C170 130 160 80 135 40 Z" fill="url(#potGrad_${artifact.id})" />
                    <path d="M45 100 Q100 120 155 100" fill="none" stroke="#fef3c7" stroke-width="4" stroke-dasharray="10,6" />
                    <path d="M40 130 Q100 150 160 130" fill="none" stroke="#fef3c7" stroke-width="4" />
                </svg>`;
        case 'manuscript':
            return `
                <svg width="${size}" height="${size}" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                    <rect x="20" y="50" width="160" height="100" rx="6" fill="#fef3c7" stroke="#92400e" stroke-width="3" />
                    <line x1="40" y1="75" x2="160" y2="75" stroke="#78350f" stroke-width="3" stroke-dasharray="15,5" />
                    <line x1="40" y1="95" x2="160" y2="95" stroke="#78350f" stroke-width="3" stroke-dasharray="10,8" />
                    <line x1="40" y1="115" x2="160" y2="115" stroke="#78350f" stroke-width="3" stroke-dasharray="20,4" />
                    <circle cx="100" cy="100" r="14" fill="#92400e" opacity="0.2" />
                    <path d="M15 100 L185 100" stroke="#b45309" stroke-width="2" />
                </svg>`;
        case 'weapon':
            return `
                <svg width="${size}" height="${size}" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                    <!-- Blade -->
                    <path d="M100 20 L112 130 L100 145 L88 130 Z" fill="#cbd5e1" stroke="#475569" stroke-width="2" />
                    <line x1="100" y1="25" x2="100" y2="135" stroke="#94a3b8" stroke-width="2" />
                    <!-- Hilt & Guard -->
                    <rect x="70" y="145" width="60" height="12" rx="4" fill="#fbbf24" stroke="#b45309" stroke-width="2" />
                    <rect x="94" y="157" width="12" height="25" rx="3" fill="#78350f" />
                    <circle cx="100" cy="188" r="10" fill="#fbbf24" stroke="#b45309" stroke-width="2" />
                </svg>`;
        case 'tut_mask':
            return `
                <svg width="${size}" height="${size}" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                    <defs>
                        <linearGradient id="tutGold_${artifact.id}" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="#fde047" />
                            <stop offset="50%" stop-color="#eab308" />
                            <stop offset="100%" stop-color="#854d0e" />
                        </linearGradient>
                    </defs>
                    <path d="M40 70 C40 30 160 30 160 70 L175 140 C170 165 130 170 130 170 L120 190 L80 190 L70 170 C70 170 30 165 25 140 Z" fill="url(#tutGold_${artifact.id})" stroke="#1e3a8a" stroke-width="4" />
                    <path d="M50 75 L150 75 M55 95 L145 95 M60 115 L140 115" stroke="#1e3a8a" stroke-width="5" stroke-linecap="round" />
                    <ellipse cx="100" cy="100" rx="32" ry="40" fill="#fde047" stroke="#854d0e" stroke-width="2" />
                    <ellipse cx="85" cy="95" rx="6" ry="4" fill="#0f172a" />
                    <ellipse cx="115" cy="95" rx="6" ry="4" fill="#0f172a" />
                    <path d="M100 35 L104 22 L96 22 Z" fill="#ef4444" stroke="#fde047" />
                    <rect x="94" y="140" width="12" height="35" rx="2" fill="#1e3a8a" stroke="#fde047" stroke-width="2" />
                </svg>`;
        case 'rosetta':
            return `
                <svg width="${size}" height="${size}" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                    <path d="M30 40 Q100 20 170 35 L165 175 C120 185 80 185 35 175 Z" fill="#1e293b" stroke="#475569" stroke-width="3" />
                    <line x1="45" y1="55" x2="155" y2="55" stroke="#94a3b8" stroke-width="3" stroke-dasharray="8,4,12,4" />
                    <line x1="45" y1="70" x2="155" y2="70" stroke="#94a3b8" stroke-width="3" stroke-dasharray="14,6,8,5" />
                    <line x1="45" y1="95" x2="155" y2="95" stroke="#cbd5e1" stroke-width="2" stroke-dasharray="5,3" />
                    <line x1="45" y1="110" x2="155" y2="110" stroke="#cbd5e1" stroke-width="2" stroke-dasharray="8,5" />
                    <line x1="45" y1="135" x2="155" y2="135" stroke="#e2e8f0" stroke-width="2" stroke-dasharray="10,4,6,4" />
                    <line x1="45" y1="150" x2="155" y2="150" stroke="#e2e8f0" stroke-width="2" stroke-dasharray="12,5" />
                </svg>`;
        case 'dancing_girl':
            return `
                <svg width="${size}" height="${size}" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                    <defs>
                        <linearGradient id="bronzeGrad_${artifact.id}" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="#b45309" />
                            <stop offset="50%" stop-color="#78350f" />
                            <stop offset="100%" stop-color="#451a03" />
                        </linearGradient>
                    </defs>
                    <rect x="60" y="175" width="80" height="15" rx="3" fill="#334155" stroke="#fbbf24" stroke-width="1.5" />
                    <circle cx="100" cy="40" r="16" fill="url(#bronzeGrad_${artifact.id})" />
                    <circle cx="114" cy="42" r="8" fill="url(#bronzeGrad_${artifact.id})" />
                    <path d="M92 56 L108 56 L104 105 L96 105 Z" fill="url(#bronzeGrad_${artifact.id})" />
                    <path d="M92 60 L70 85 L90 100" fill="none" stroke="url(#bronzeGrad_${artifact.id})" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" />
                    <path d="M108 60 L125 90 L120 120" fill="none" stroke="url(#bronzeGrad_${artifact.id})" stroke-width="6" stroke-linecap="round" />
                    <path d="M96 105 L90 175 M104 105 L110 175" stroke="url(#bronzeGrad_${artifact.id})" stroke-width="8" stroke-linecap="round" />
                </svg>`;
        case 'aztec_sun':
            return `
                <svg width="${size}" height="${size}" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                    <defs>
                        <radialGradient id="sunGrad_${artifact.id}" cx="50%" cy="50%" r="50%">
                            <stop offset="0%" stop-color="#f59e0b" />
                            <stop offset="70%" stop-color="#b45309" />
                            <stop offset="100%" stop-color="#78350f" />
                        </radialGradient>
                    </defs>
                    <circle cx="100" cy="100" r="85" fill="url(#sunGrad_${artifact.id})" stroke="#fbbf24" stroke-width="4" />
                    <circle cx="100" cy="100" r="70" fill="none" stroke="#fef3c7" stroke-width="2" stroke-dasharray="8,4" />
                    <circle cx="100" cy="100" r="50" fill="none" stroke="#fef3c7" stroke-width="2" stroke-dasharray="12,6" />
                    <circle cx="100" cy="100" r="30" fill="#78350f" stroke="#fbbf24" stroke-width="3" />
                    <path d="M100 15 L108 30 L92 30 Z M100 185 L108 170 L92 170 Z M15 100 L30 92 L30 108 Z M185 100 L170 92 L170 108 Z" fill="#fbbf24" />
                    <text x="100" y="108" font-size="20" fill="#fde047" text-anchor="middle">☀️</text>
                </svg>`;
        case 'terracotta':
            return `
                <svg width="${size}" height="${size}" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                    <defs>
                        <linearGradient id="terraGrad_${artifact.id}" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="#d97706" />
                            <stop offset="50%" stop-color="#9a3412" />
                            <stop offset="100%" stop-color="#451a03" />
                        </linearGradient>
                    </defs>
                    <rect x="55" y="170" width="90" height="18" rx="3" fill="#334155" stroke="#9a3412" stroke-width="2" />
                    <circle cx="94" cy="35" r="7" fill="url(#terraGrad_${artifact.id})" />
                    <circle cx="100" cy="50" r="16" fill="url(#terraGrad_${artifact.id})" stroke="#7c2d12" stroke-width="1.5" />
                    <path d="M75 70 L125 70 L130 135 L70 135 Z" fill="url(#terraGrad_${artifact.id})" stroke="#7c2d12" stroke-width="2" />
                    <path d="M80 80 L120 80 M82 95 L118 95 M84 110 L116 110" stroke="#fef3c7" stroke-width="2" stroke-dasharray="5,4" />
                    <rect x="80" y="135" width="16" height="35" fill="url(#terraGrad_${artifact.id})" />
                    <rect x="104" y="135" width="16" height="35" fill="url(#terraGrad_${artifact.id})" />
                </svg>`;
        case 'cyrus_cylinder':
            return `
                <svg width="${size}" height="${size}" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                    <defs>
                        <linearGradient id="cylGrad_${artifact.id}" x1="0%" y1="0%" x2="0%" y2="100%">
                            <stop offset="0%" stop-color="#d97706" />
                            <stop offset="50%" stop-color="#b45309" />
                            <stop offset="100%" stop-color="#78350f" />
                        </linearGradient>
                    </defs>
                    <path d="M40 80 C40 50 160 50 160 80 L160 120 C160 150 40 150 40 120 Z" fill="url(#cylGrad_${artifact.id})" stroke="#92400e" stroke-width="3" />
                    <ellipse cx="40" cy="100" rx="12" ry="25" fill="#78350f" stroke="#92400e" stroke-width="2" />
                    <ellipse cx="160" cy="100" rx="12" ry="25" fill="#b45309" stroke="#92400e" stroke-width="2" />
                    <line x1="55" y1="75" x2="145" y2="75" stroke="#fef3c7" stroke-width="2" stroke-dasharray="4,3,8,3" />
                    <line x1="55" y1="90" x2="145" y2="90" stroke="#fef3c7" stroke-width="2" stroke-dasharray="7,4,5,2" />
                    <line x1="55" y1="105" x2="145" y2="105" stroke="#fef3c7" stroke-width="2" stroke-dasharray="10,3,4,3" />
                    <line x1="55" y1="120" x2="145" y2="120" stroke="#fef3c7" stroke-width="2" stroke-dasharray="6,4,8,2" />
                </svg>`;
        case 'statue':
        default:
            return `
                <svg width="${size}" height="${size}" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                    <defs>
                        <linearGradient id="statueGrad_${artifact.id}" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stop-color="#fbbf24" />
                            <stop offset="50%" stop-color="${color}" />
                            <stop offset="100%" stop-color="#451a03" />
                        </linearGradient>
                    </defs>
                    <rect x="50" y="165" width="100" height="20" rx="4" fill="#334155" stroke="#fbbf24" stroke-width="2" />
                    <circle cx="100" cy="75" r="55" fill="none" stroke="#fbbf24" stroke-width="3" stroke-dasharray="8,4" />
                    <circle cx="100" cy="55" r="20" fill="url(#statueGrad_${artifact.id})" />
                    <path d="M80 80 Q100 70 120 80 L135 125 Q100 145 65 125 Z" fill="url(#statueGrad_${artifact.id})" />
                    <path d="M60 90 L40 120 Q35 125 45 130 L70 105 Z" fill="url(#statueGrad_${artifact.id})" />
                    <path d="M140 90 L160 120 Q165 125 155 130 L130 105 Z" fill="url(#statueGrad_${artifact.id})" />
                </svg>`;
    }
}

// --------------------------------------------------------------------------
// 5. Theme Toggle Engine
// --------------------------------------------------------------------------
function initTheme() {
    const savedTheme = localStorage.getItem('ar_museum_theme') || 'dark';
    document.documentElement.setAttribute('data-theme', savedTheme);
    updateThemeIcon(savedTheme);

    const toggleBtn = document.getElementById('theme-toggle');
    if (toggleBtn) {
        toggleBtn.addEventListener('click', () => {
            const current = document.documentElement.getAttribute('data-theme');
            const next = current === 'dark' ? 'light' : 'dark';
            document.documentElement.setAttribute('data-theme', next);
            localStorage.setItem('ar_museum_theme', next);
            updateThemeIcon(next);
            showToast(`Switched to ${next.toUpperCase()} theme`, "☀️");
        });
    }
}

function updateThemeIcon(theme) {
    const icon = document.querySelector('#theme-toggle .theme-icon');
    if (icon) icon.textContent = theme === 'dark' ? '🌙' : '☀️';
}

// --------------------------------------------------------------------------
// 6. SPA Router Navigation
// --------------------------------------------------------------------------
function showSection(sectionId) {
    activeSection = sectionId;

    // Toggle active section visibility
    document.querySelectorAll('.section').forEach(sec => sec.classList.remove('active'));
    const targetSec = document.getElementById(`sec-${sectionId}`);
    if (targetSec) targetSec.classList.add('active');

    // Update nav links
    document.querySelectorAll('.nav-item').forEach(nav => nav.classList.remove('active'));
    const activeNav = document.getElementById(`nav-${sectionId}`);
    if (activeNav) activeNav.classList.add('active');

    // Close mobile menu if open
    const navLinks = document.getElementById('nav-links');
    if (navLinks) navLinks.classList.remove('mobile-open');

    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });

    // Handle section-specific triggers
    if (sectionId === 'ar') {
        const statusText = document.getElementById('ar-status-text');
        if (statusText) statusText.textContent = "3D AR Studio Active ✓";
    }

    if (sectionId === 'favorites') {
        renderFavoritesGrid();
    }

    if (sectionId === 'dashboard') {
        updateDashboardStats();
    }
}

// --------------------------------------------------------------------------
// 7. Hero Preview & Dashboard Engine
// --------------------------------------------------------------------------
function renderHeroPreview() {
    const heroWrapper = document.getElementById('hero-preview-svg');
    if (heroWrapper && artifactsState.length > 0) {
        heroWrapper.innerHTML = renderArtifactSVG(artifactsState[0], 240);
    }
}

function updateDashboardStats() {
    const totalArt = document.getElementById('stat-total-artifacts');
    const totalCat = document.getElementById('stat-total-categories');
    const arScans = document.getElementById('stat-ar-scans');
    const favCount = document.getElementById('stat-favorites-count');

    if (totalArt) totalArt.textContent = artifactsState.length.toString();

    // Unique categories count
    const categories = new Set(artifactsState.map(a => a.category));
    if (totalCat) totalCat.textContent = categories.size.toString();

    if (arScans) arScans.textContent = arScanCount.toString();
    if (favCount) favCount.textContent = favoritesState.length.toString();

    renderDashboardRecent();
}

function renderDashboardRecent() {
    const container = document.getElementById('dashboard-recent-grid');
    if (!container) return;

    if (recentState.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <span class="empty-icon">🏺</span>
                <p>No recently viewed artifacts yet. Explore the catalogue!</p>
            </div>`;
        return;
    }

    const recentItems = recentState
        .map(id => artifactsState.find(a => a.id === id))
        .filter(Boolean)
        .slice(0, 4);

    container.innerHTML = recentItems.map(item => createArtifactCardHTML(item)).join('');
}

// --------------------------------------------------------------------------
// 8. Catalogue Render, Search & Filter
// --------------------------------------------------------------------------
function renderExploreGrid() {
    const grid = document.getElementById('explore-grid');
    if (!grid) return;

    let items = [...artifactsState];

    // Category Filter
    if (currentCategory !== 'All') {
        items = items.filter(a => a.category.toLowerCase() === currentCategory.toLowerCase());
    }

    // Search Query Filter
    if (searchQuery.trim() !== '') {
        const q = searchQuery.toLowerCase().trim();
        items = items.filter(a =>
            a.name.toLowerCase().includes(q) ||
            a.category.toLowerCase().includes(q) ||
            a.period.toLowerCase().includes(q) ||
            a.origin.toLowerCase().includes(q)
        );
    }

    // Sort Order
    if (currentSort === 'newest') {
        items.sort((a, b) => b.id - a.id);
    } else if (currentSort === 'oldest') {
        items.sort((a, b) => a.id - b.id);
    } else if (currentSort === 'az') {
        items.sort((a, b) => a.name.localeCompare(b.name));
    }

    if (items.length === 0) {
        grid.innerHTML = `
            <div class="empty-state">
                <span class="empty-icon">🔍</span>
                <h3>No artifacts found</h3>
                <p class="text-muted">Try adjusting your search terms or category filters.</p>
            </div>`;
        return;
    }

    grid.innerHTML = items.map(item => createArtifactCardHTML(item)).join('');
}

function createArtifactCardHTML(artifact) {
    const isFav = favoritesState.includes(artifact.id);
    return `
        <div class="artifact-card">
            <div class="card-visual-wrapper">
                <span class="card-cat-badge">${escapeHTML(artifact.category)}</span>
                <button class="card-fav-btn ${isFav ? 'is-fav' : ''}" 
                        onclick="toggleFavorite(${artifact.id}, event)" 
                        title="${isFav ? 'Remove Favorite' : 'Add Favorite'}">
                    ${isFav ? '♥' : '♡'}
                </button>
                ${renderArtifactSVG(artifact, 160)}
            </div>
            <div class="card-content">
                <h3 class="card-title">${escapeHTML(artifact.name)}</h3>
                <div class="card-meta">
                    <span>🏛️ <strong>Period:</strong> ${escapeHTML(artifact.period)}</span>
                    <span>📍 <strong>Origin:</strong> ${escapeHTML(artifact.origin)}</span>
                </div>
                <div class="card-actions">
                    <button class="btn btn-secondary btn-sm" onclick="openDetailsModal(${artifact.id})">Details</button>
                    <button class="btn btn-accent btn-sm" onclick="start360WithArtifact(${artifact.id})">🔄 360° View</button>
                    <button class="btn btn-primary btn-sm" onclick="startARWithArtifact(${artifact.id})">📱 View Studio</button>
                </div>
            </div>
        </div>`;
}

function renderFavoritesGrid() {
    const grid = document.getElementById('favorites-grid');
    if (!grid) return;

    const favItems = favoritesState
        .map(id => artifactsState.find(a => a.id === id))
        .filter(Boolean);

    if (favItems.length === 0) {
        grid.innerHTML = `
            <div class="empty-state">
                <span class="empty-icon">❤️</span>
                <h3>No Favorite Artifacts Saved</h3>
                <p class="text-muted">Click the heart icon on any artifact card to add it to your personal favorites!</p>
                <button class="btn btn-primary margin-top-md" onclick="showSection('explore')">Explore Artifacts</button>
            </div>`;
        return;
    }

    grid.innerHTML = favItems.map(item => createArtifactCardHTML(item)).join('');
}

function toggleFavorite(id, event) {
    if (event) event.stopPropagation();

    const index = favoritesState.indexOf(id);
    if (index > -1) {
        favoritesState.splice(index, 1);
        showToast("Removed from favorites", "💔");
    } else {
        favoritesState.push(id);
        showToast("Added to favorites ✓", "❤️");
    }

    saveFavoritesToStorage();
    renderExploreGrid();
    if (activeSection === 'favorites') renderFavoritesGrid();
}

// --------------------------------------------------------------------------
// 9. Details Modal Engine
// --------------------------------------------------------------------------
function openDetailsModal(id) {
    const artifact = artifactsState.find(a => a.id === id);
    if (!artifact) return;

    // Track recently viewed
    if (!recentState.includes(id)) {
        recentState.unshift(id);
        if (recentState.length > 10) recentState.pop();
        saveRecentToStorage();
    }

    const isFav = favoritesState.includes(id);
    const body = document.getElementById('details-modal-body');
    if (!body) return;

    const factsList = (artifact.facts || [])
        .map(fact => `<li>• ${escapeHTML(fact)}</li>`)
        .join('');

    body.innerHTML = `
        <div class="details-view">
            <div class="details-visual-col">
                ${renderArtifactSVG(artifact, 220)}
            </div>
            <div class="details-info-col">
                <span class="details-meta-pill">${escapeHTML(artifact.category)}</span>
                <h2>${escapeHTML(artifact.name)}</h2>
                <div class="card-meta margin-top-md">
                    <p><strong>Historical Period:</strong> ${escapeHTML(artifact.period)}</p>
                    <p><strong>Origin / Location:</strong> ${escapeHTML(artifact.origin)}</p>
                    <p><strong>Approximate Era:</strong> ${escapeHTML(artifact.year)}</p>
                </div>
                <div class="margin-top-md">
                    <h4>Historical Description</h4>
                    <p class="text-muted" style="font-size: 0.95rem; margin-top: 0.3rem;">${escapeHTML(artifact.description)}</p>
                </div>
                <div class="margin-top-md">
                    <h4>Archaeological Significance</h4>
                    <p class="text-muted" style="font-size: 0.95rem; margin-top: 0.3rem;">${escapeHTML(artifact.significance)}</p>
                </div>
                ${factsList ? `
                <div class="details-facts">
                    <h4>Interesting Historical Facts</h4>
                    <ul>${factsList}</ul>
                </div>` : ''}
                <div class="modal-actions margin-top-lg">
                    <button class="btn btn-primary" onclick="closeModal('details-modal'); start360WithArtifact(${artifact.id});">🔄 Explore in 360°</button>
                    <button class="btn btn-secondary" onclick="closeModal('details-modal'); startARWithArtifact(${artifact.id});">📱 View in Studio</button>
                    <button class="btn btn-accent" onclick="toggleFavorite(${artifact.id}); openDetailsModal(${artifact.id});">
                        ${isFav ? '♥ Saved Favorite' : '♡ Add to Favorites'}
                    </button>
                </div>
            </div>
        </div>`;

    document.getElementById('details-modal').classList.remove('hidden');
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.add('hidden');
}

// --------------------------------------------------------------------------
// 10. 3D AR Virtual Studio & Interactive Physics
// --------------------------------------------------------------------------
function populateARArtifactSelect() {
    const select = document.getElementById('ar-artifact-select');
    if (!select) return;

    select.innerHTML = artifactsState.map(a => `
        <option value="${a.id}" ${a.id === selectedARArtifactId ? 'selected' : ''}>
            ${escapeHTML(a.name)}
        </option>
    `).join('');

    select.addEventListener('change', (e) => {
        selectedARArtifactId = parseInt(e.target.value, 10);
        updateARArtifactOverlay();
    });
}

function startARWithArtifact(id) {
    selectedARArtifactId = id;
    showSection('ar');
    const select = document.getElementById('ar-artifact-select');
    if (select) select.value = id;
    updateARArtifactOverlay();
    showToast("3D Studio Exhibition Active", "📱");
}

function start360WithArtifact(id) {
    selectedARArtifactId = id;
    showSection('ar');
    const select = document.getElementById('ar-artifact-select');
    if (select) select.value = id;
    updateARArtifactOverlay();
    stopAuto360Spin();
    showToast("Drag mouse cursor across stage to rotate 360° 🔄", "🖱️");
}

function updateARArtifactOverlay() {
    const artifact = artifactsState.find(a => a.id === selectedARArtifactId) || artifactsState[0];
    
    // Update Title tag
    const titleTag = document.getElementById('ar-current-name');
    if (titleTag) titleTag.textContent = artifact.name;

    // Render 3D SVG into wrapper
    const wrapper = document.getElementById('ar-model-wrapper');
    if (wrapper) {
        wrapper.innerHTML = renderArtifactSVG(artifact, 260);
    }

    // Update overlay info card
    document.getElementById('ar-info-title').textContent = artifact.name;
    document.getElementById('ar-info-period').textContent = artifact.period;
    document.getElementById('ar-info-origin').textContent = artifact.origin;
    document.getElementById('ar-info-year').textContent = artifact.year;
    document.getElementById('ar-info-desc').textContent = artifact.description;

    resetARTransform();
}

// (Camera access removed - 3D Virtual AR Studio Mode Active)

// 360° Turntable Auto-Spin Logic
function startAuto360Spin() {
    if (isAutoSpinning) return;
    isAutoSpinning = true;
    const btn = document.getElementById('ar-btn-auto-360');
    if (btn) btn.classList.add('active-360');

    function spinLoop() {
        if (!isAutoSpinning) return;
        arTransform.rotY = (arTransform.rotY + 1.2) % 360;
        applyARTransform();
        autoSpinAnimationFrame = requestAnimationFrame(spinLoop);
    }
    spinLoop();
}

function stopAuto360Spin() {
    isAutoSpinning = false;
    if (autoSpinAnimationFrame) {
        cancelAnimationFrame(autoSpinAnimationFrame);
        autoSpinAnimationFrame = null;
    }
    const btn = document.getElementById('ar-btn-auto-360');
    if (btn) btn.classList.remove('active-360');
}

function toggleAuto360Spin() {
    if (isAutoSpinning) {
        stopAuto360Spin();
        showToast("360° Auto-Spin Paused", "⏸️");
    } else {
        startAuto360Spin();
        showToast("360° Auto-Spin Active 🔄", "✨");
    }
}

function set360Angle(angle) {
    stopAuto360Spin();
    arTransform.rotY = angle;
    applyARTransform();
    showToast(`360° Angle set to ${angle}°`, "🧭");
}

// AR Mouse & Touch 360 Degree Drag Interaction Engine
let isPointerDown = false;
let pointerLastPos = { x: 0, y: 0 };
let velocity = { x: 0, y: 0 };
let momentumFrame = null;

function setupARInteractions() {
    const stage = document.getElementById('ar-stage');
    const overlay = document.getElementById('ar-artifact-overlay');
    if (!stage || !overlay) return;

    const onPointerDown = (clientX, clientY, target) => {
        if (target.closest('.ar-bottom-controls') || 
            target.closest('.ar-top-bar') || 
            target.closest('.ar-360-presets-bar') || 
            target.closest('.ar-info-overlay')) {
            return;
        }
        isPointerDown = true;
        stopAuto360Spin();
        if (momentumFrame) cancelAnimationFrame(momentumFrame);
        pointerLastPos = { x: clientX, y: clientY };
        velocity = { x: 0, y: 0 };
    };

    const onPointerMove = (clientX, clientY) => {
        if (!isPointerDown) return;
        const deltaX = clientX - pointerLastPos.x;
        const deltaY = clientY - pointerLastPos.y;

        velocity.x = deltaX;
        velocity.y = deltaY;

        // Mouse X controls 360° Y-axis rotation
        arTransform.rotY = (arTransform.rotY + deltaX * 0.7) % 360;
        // Mouse Y controls X-axis pitch tilt
        arTransform.rotX = Math.max(-50, Math.min(50, (arTransform.rotX || 0) - deltaY * 0.4));

        pointerLastPos = { x: clientX, y: clientY };
        applyARTransform();
    };

    const onPointerUp = () => {
        if (!isPointerDown) return;
        isPointerDown = false;

        function glide() {
            if (Math.abs(velocity.x) < 0.1 && Math.abs(velocity.y) < 0.1) return;
            velocity.x *= 0.92;
            velocity.y *= 0.92;
            arTransform.rotY = (arTransform.rotY + velocity.x * 0.7) % 360;
            arTransform.rotX = Math.max(-50, Math.min(50, (arTransform.rotX || 0) - velocity.y * 0.4));
            applyARTransform();
            momentumFrame = requestAnimationFrame(glide);
        }
        glide();
    };

    stage.addEventListener('mousedown', (e) => onPointerDown(e.clientX, e.clientY, e.target));
    window.addEventListener('mousemove', (e) => onPointerMove(e.clientX, e.clientY));
    window.addEventListener('mouseup', onPointerUp);

    stage.addEventListener('touchstart', (e) => {
        if (e.touches.length === 1) onPointerDown(e.touches[0].clientX, e.touches[0].clientY, e.target);
    });
    window.addEventListener('touchmove', (e) => {
        if (e.touches.length === 1) onPointerMove(e.touches[0].clientX, e.touches[0].clientY);
    });
    window.addEventListener('touchend', onPointerUp);

    // 360 Auto Spin Button
    document.getElementById('ar-btn-auto-360')?.addEventListener('click', toggleAuto360Spin);

    // Control Buttons
    document.getElementById('ar-btn-rot-left')?.addEventListener('click', () => {
        stopAuto360Spin();
        arTransform.rotY -= 15;
        applyARTransform();
    });

    document.getElementById('ar-btn-rot-right')?.addEventListener('click', () => {
        stopAuto360Spin();
        arTransform.rotY += 15;
        applyARTransform();
    });

    document.getElementById('ar-btn-zoom-in')?.addEventListener('click', () => {
        arTransform.scale = Math.min(2.5, arTransform.scale + 0.15);
        applyARTransform();
    });

    document.getElementById('ar-btn-zoom-out')?.addEventListener('click', () => {
        arTransform.scale = Math.max(0.4, arTransform.scale - 0.15);
        applyARTransform();
    });

    document.getElementById('ar-btn-reset')?.addEventListener('click', resetARTransform);

    document.getElementById('ar-btn-info')?.addEventListener('click', () => {
        const infoOverlay = document.getElementById('ar-info-overlay');
        infoOverlay.classList.toggle('hidden');
    });

    document.getElementById('ar-btn-capture')?.addEventListener('click', captureARSnapshot);
}

function applyARTransform() {
    const overlay = document.getElementById('ar-artifact-overlay');
    if (overlay) {
        overlay.style.transform = `translate(calc(-50% + ${arTransform.posX}px), calc(-50% + ${arTransform.posY}px)) rotateX(${arTransform.rotX || 0}deg) rotateY(${arTransform.rotY}deg) rotateZ(${arTransform.rotZ}deg) scale(${arTransform.scale})`;
    }

    // Update 360 degree value badge
    const angleBadge = document.getElementById('ar-angle-badge');
    if (angleBadge) {
        let deg = Math.round(arTransform.rotY % 360);
        if (deg < 0) deg += 360;
        angleBadge.textContent = `${deg}°`;
    }

    // Highlight preset button if exact match
    document.querySelectorAll('.ar-360-presets-bar .preset-btn').forEach(btn => {
        const val = parseInt(btn.textContent, 10);
        let currentDeg = Math.round(arTransform.rotY % 360);
        if (currentDeg < 0) currentDeg += 360;
        if (val === currentDeg) btn.classList.add('active');
        else btn.classList.remove('active');
    });
}

function resetARTransform() {
    stopAuto360Spin();
    arTransform = { posX: 0, posY: 0, rotX: 0, rotY: 0, rotZ: 0, scale: 1.0 };
    applyARTransform();
}

function toggleARInfoOverlay(show) {
    const infoOverlay = document.getElementById('ar-info-overlay');
    if (infoOverlay) {
        if (show === undefined) infoOverlay.classList.toggle('hidden');
        else if (show) infoOverlay.classList.remove('hidden');
        else infoOverlay.classList.add('hidden');
    }
}

// Canvas Composite Screenshot Generator
function captureARSnapshot() {
    const stage = document.getElementById('ar-stage');
    const artifact = artifactsState.find(a => a.id === selectedARArtifactId) || artifactsState[0];

    const canvas = document.createElement('canvas');
    canvas.width = stage.clientWidth || 800;
    canvas.height = stage.clientHeight || 600;
    const ctx = canvas.getContext('2d');

    // 1. Draw 3D Studio Exhibition Background
    const grad = ctx.createRadialGradient(canvas.width/2, canvas.height * 0.4, 50, canvas.width/2, canvas.height/2, canvas.width);
    grad.addColorStop(0, '#1e293b');
    grad.addColorStop(0.6, '#0f172a');
    grad.addColorStop(1, '#050811');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw studio floor pedestal glow
    const pedestalGrad = ctx.createRadialGradient(canvas.width/2, canvas.height * 0.7, 10, canvas.width/2, canvas.height * 0.7, 200);
    pedestalGrad.addColorStop(0, 'rgba(245, 158, 11, 0.25)');
    pedestalGrad.addColorStop(1, 'rgba(245, 158, 11, 0)');
    ctx.fillStyle = pedestalGrad;
    ctx.beginPath();
    ctx.ellipse(canvas.width/2, canvas.height * 0.7, 200, 60, 0, 0, Math.PI * 2);
    ctx.fill();

    // 2. Draw HUD reticle watermark
    ctx.strokeStyle = 'rgba(245, 158, 11, 0.4)';
    ctx.lineWidth = 3;
    ctx.strokeRect(30, 30, canvas.width - 60, canvas.height - 60);

    // 3. Composite Artifact SVG onto Canvas
    const svgString = renderArtifactSVG(artifact, 260);
    const img = new Image();
    const svgBlob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(svgBlob);

    img.onload = () => {
        ctx.save();
        // Translate to artifact position
        const centerX = canvas.width / 2 + arTransform.posX;
        const centerY = canvas.height / 2 + arTransform.posY;
        ctx.translate(centerX, centerY);
        ctx.rotate((arTransform.rotZ * Math.PI) / 180);
        ctx.scale(arTransform.scale, arTransform.scale);
        ctx.drawImage(img, -130, -130, 260, 260);
        ctx.restore();

        // Title watermark
        ctx.fillStyle = '#ffffff';
        ctx.font = '16px Cinzel, serif';
        ctx.fillText(`AR HISTORICAL MUSEUM • ${artifact.name.toUpperCase()}`, 40, canvas.height - 40);

        URL.revokeObjectURL(url);

        // Export & Preview
        const dataURL = canvas.toDataURL('image/png');
        const previewImg = document.getElementById('snapshot-preview-img');
        const downloadBtn = document.getElementById('snapshot-download-btn');

        if (previewImg) previewImg.src = dataURL;
        if (downloadBtn) downloadBtn.href = dataURL;

        incrementARScanCount();
        document.getElementById('snapshot-modal').classList.remove('hidden');
        showToast("AR Snapshot captured successfully! 📸", "✨");
    };
    img.src = url;
}

// --------------------------------------------------------------------------
// 11. Admin Simulation Engine (CRUD)
// --------------------------------------------------------------------------
function renderAdminTable() {
    const tbody = document.getElementById('admin-table-body');
    if (!tbody) return;

    tbody.innerHTML = artifactsState.map(a => `
        <tr>
            <td>#${a.id}</td>
            <td><strong>${escapeHTML(a.name)}</strong></td>
            <td><span class="details-meta-pill" style="margin:0;">${escapeHTML(a.category)}</span></td>
            <td>${escapeHTML(a.period)}</td>
            <td>${escapeHTML(a.origin)}</td>
            <td>${escapeHTML(a.year)}</td>
            <td>
                <button class="btn btn-secondary btn-sm" onclick="openEditAdminModal(${a.id})">✏️ Edit</button>
                <button class="btn btn-outline btn-sm" style="color:var(--danger);" onclick="deleteAdminArtifact(${a.id})">🗑️ Delete</button>
            </td>
        </tr>
    `).join('');
}

function openAddAdminModal() {
    document.getElementById('admin-modal-title').textContent = "Add New Artifact";
    document.getElementById('admin-artifact-id').value = "";
    document.getElementById('admin-form').reset();
    document.getElementById('admin-modal').classList.remove('hidden');
}

function openEditAdminModal(id) {
    const artifact = artifactsState.find(a => a.id === id);
    if (!artifact) return;

    document.getElementById('admin-modal-title').textContent = "Edit Artifact";
    document.getElementById('admin-artifact-id').value = artifact.id;
    document.getElementById('admin-name').value = artifact.name;
    document.getElementById('admin-category').value = artifact.category;
    document.getElementById('admin-period').value = artifact.period;
    document.getElementById('admin-origin').value = artifact.origin;
    document.getElementById('admin-year').value = artifact.year;
    document.getElementById('admin-visual-type').value = artifact.visualType || 'statue';
    document.getElementById('admin-desc').value = artifact.description;
    document.getElementById('admin-significance').value = artifact.significance;

    document.getElementById('admin-modal').classList.remove('hidden');
}

function handleAdminFormSubmit(event) {
    event.preventDefault();

    const idInput = document.getElementById('admin-artifact-id').value;
    const name = document.getElementById('admin-name').value.trim();
    const category = document.getElementById('admin-category').value;
    const period = document.getElementById('admin-period').value.trim();
    const origin = document.getElementById('admin-origin').value.trim();
    const year = document.getElementById('admin-year').value.trim();
    const visualType = document.getElementById('admin-visual-type').value;
    const description = document.getElementById('admin-desc').value.trim();
    const significance = document.getElementById('admin-significance').value.trim();

    if (!name || !period || !origin || !description || !significance) {
        showToast("Please fill in all required fields", "⚠️");
        return;
    }

    if (idInput) {
        // Edit existing
        const id = parseInt(idInput, 10);
        const item = artifactsState.find(a => a.id === id);
        if (item) {
            item.name = name;
            item.category = category;
            item.period = period;
            item.origin = origin;
            item.year = year;
            item.visualType = visualType;
            item.description = description;
            item.significance = significance;
            showToast("Artifact updated successfully! 💾", "✨");
        }
    } else {
        // Add new
        const newId = Date.now();
        const newItem = {
            id: newId,
            name,
            category,
            period,
            origin,
            year,
            visualType,
            description,
            significance,
            color: '#f59e0b',
            facts: ["Newly curated artifact added via Admin Studio."]
        };
        artifactsState.unshift(newItem);
        showToast("New artifact saved to collection! 🏺", "✨");
    }

    // Save custom array to localStorage
    const customItems = artifactsState.filter(a => !initialArtifacts.some(init => init.id === a.id));
    saveCustomArtifactsToStorage(customItems);

    closeModal('admin-modal');
    renderAdminTable();
    renderExploreGrid();
    populateARArtifactSelect();
    updateDashboardStats();
}

function deleteAdminArtifact(id) {
    if (!confirm("Are you sure you want to delete this artifact record?")) return;

    artifactsState = artifactsState.filter(a => a.id !== id);

    // Save custom array to localStorage
    const customItems = artifactsState.filter(a => !initialArtifacts.some(init => init.id === a.id));
    saveCustomArtifactsToStorage(customItems);

    showToast("Artifact record deleted", "🗑️");
    renderAdminTable();
    renderExploreGrid();
    populateARArtifactSelect();
    updateDashboardStats();
}

// --------------------------------------------------------------------------
// 12. Global Event Listeners
// --------------------------------------------------------------------------
function setupEventListeners() {
    // Search bar input
    const searchInput = document.getElementById('search-input');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            searchQuery = e.target.value;
            renderExploreGrid();
        });
    }

    // Sort select
    const sortSelect = document.getElementById('sort-select');
    if (sortSelect) {
        sortSelect.addEventListener('change', (e) => {
            currentSort = e.target.value;
            renderExploreGrid();
        });
    }

    // Category Pills
    const pills = document.querySelectorAll('#category-pills .pill');
    pills.forEach(pill => {
        pill.addEventListener('click', () => {
            pills.forEach(p => p.classList.remove('active'));
            pill.classList.add('active');
            currentCategory = pill.getAttribute('data-category');
            renderExploreGrid();
        });
    });

    // Mobile Navigation Drawer Toggle
    const mobileBtn = document.getElementById('mobile-menu-btn');
    const navLinks = document.getElementById('nav-links');
    if (mobileBtn && navLinks) {
        mobileBtn.addEventListener('click', () => {
            navLinks.classList.toggle('mobile-open');
        });
    }
}

// --------------------------------------------------------------------------
// 13. Toast Notification Utility
// --------------------------------------------------------------------------
function showToast(message, icon = "✨") {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `<span class="toast-icon">${icon}</span><span>${escapeHTML(message)}</span>`;

    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(50px)';
        toast.style.transition = '0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Helper: Escape HTML strings to prevent XSS
function escapeHTML(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}
